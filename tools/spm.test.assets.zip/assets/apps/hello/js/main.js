define(function (require) {
    
    //Get module.exports
    var Spinning = require('./spinning');
    var Mustache = require('mustache');
    var $ = require('jquery');
    
    //Make pictures spin
    var s = new Spinning('#container');
    s.render();
    
    //Get i18n resource value
    var lang = require('i18n!lang');
    console.log('-------resource value in lang.js');
    for (var prop in lang)
        console.log(prop + "=" + lang[prop]);
    
    //Construct User
    var user = {
        name : lang['name'],
        email : lang['email']
    }
    
    //Get template
    var usertpl = require('./tpl/userinfo.tpl');
    console.log("-------tpl content = " + usertpl);
    
    //Bind date to template and show
    $("#user").html(Mustache.render(usertpl, user));
    
})
