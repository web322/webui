define({
    'name': '我是谁',
    'email': 'test1234@gmail.com'
});
