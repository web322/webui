define("apps/hello/1.0.0/spinning-debug", ["gallery/jquery/1.8.3/jquery-debug"], function(require, exports, module) {

  var $ = require('gallery/jquery/1.8.3/jquery-debug')

  var TRANSFORM = $.browser.webkit ? '-webkit-transform' :
                  $.browser.mozilla ? '-moz-transform' :
                  $.browser.opera ? '-o-transform' : 'transform'

  function random(x) { return Math.random() * x }


  function Spinning(container) {
    this.container = $(container)
    this.icons = this.container.children()
    this.spinnings = []
  }

  Spinning.prototype.render = function() {
    this._init()
    this.container.show()
    this._spin()
  }

  Spinning.prototype._init = function() {
    var spinnings = this.spinnings

    $(this.icons).each(function(n) {
      var startDeg = random(360)
      var node = $(this)
      var timer

      node.css({
        top: random(40),
        left: n * 50 + random(10),
        zIndex: 1000
      }).hover(
          function() {
            node.fadeTo(250, 1)
                .css('zIndex', 1001)
                .css(TRANSFORM, 'rotate(0deg)')

          },
          function() {
            node.fadeTo(250, .6).css('zIndex', 1000)
            timer && clearTimeout(timer)
            timer = setTimeout(spin, Math.ceil(random(10000)))
          }
      )

      function spin() {
        node.css(TRANSFORM, 'rotate(' + startDeg + 'deg)')
      }

      spinnings[n] = spin
    })

    return this
  }

  Spinning.prototype._spin = function() {

    $(this.spinnings).each(function(i, fn) {
      setTimeout(fn, Math.ceil(random(3000)))
    })

    return this
  }


  module.exports = Spinning
})

define("apps/hello/1.0.0/main-debug", ["./spinning-debug", "gallery/jquery/1.8.3/jquery-debug", "gallery/mustache/0.5.0/mustache-debug", "i18n!lang-debug"], function (require) {
    
    //Get module.exports
    var Spinning = require('./spinning-debug');
    var Mustache = require('gallery/mustache/0.5.0/mustache-debug');
    var $ = require('gallery/jquery/1.8.3/jquery-debug');
    
    //Make pictures spin
    var s = new Spinning('#container');
    s.render();
    
    //Get i18n resource value
    var lang = require('i18n!lang-debug');
    console.log('-------resource value in lang.js');
    for (var prop in lang)
        console.log(prop + "=" + lang[prop]);
    
    //Construct User
    var user = {
        name : lang['name'],
        email : lang['email']
    }
    
    //Get template
    var usertpl = 'my name is {{name}}, my email is {{email}}';
    console.log("-------tpl content = " + usertpl);
    
    //Bind date to template and show
    $("#user").html(Mustache.render(usertpl, user));
    
})
